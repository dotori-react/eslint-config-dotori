# `eslint-config-dotori-react`

> TODO: description

## Usage

```
const eslintConfigDotoriReact = require('eslint-config-dotori-react');

// TODO: DEMONSTRATE API
```
