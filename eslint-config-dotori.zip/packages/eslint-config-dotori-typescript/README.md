# `eslint-config-dotori-typescript`

> TODO: description

## Usage

```
const eslintConfigDotoriTypescript = require('eslint-config-dotori-typescript');

// TODO: DEMONSTRATE API
```
