# `eslint-config-dotori`

> TODO: description

## Usage

```
const eslintConfigDotori = require('eslint-config-dotori');

// TODO: DEMONSTRATE API
```
